Cloudbanking PrestaShop payment module

Install module

Backup your webstore and database

Download cloudbanking.zip

Login to your PrestaShop admin area and select the Modules->Modules & Services menu

Upload the archive cloudbanking.zip via a module installer
Upload a new module

Locate cloudbanking in available modules and install it
Install module

Module configuration

At the payment module configuration page:

Enter in fields Authkey, Api Version and Customer id.


You are done!

Notes

Tested and developed with PrestaShop 1.7



