<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
require_once(__DIR__ . '/vendor/autoload.php');

use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Cloudbanking extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;

    public function __construct()
    {
        $this->name = 'cloudbanking';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->author = 'Cloudbanking';
        $this->controllers = array('validation');
        $this->is_eu_compatible = 1;

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Cloudbanking');
        $this->description = $this->l('Cloudbanking Payment Module');
        $authkey  = trim(Configuration::get('CLOUDBANKING_AUTH_KEY'));
        $api_version = trim(Configuration::get('CLOUDBANKING_API_VERSION'));
        $customer_id = trim(Configuration::get('CLOUDBANKING_CUSTOMER_ID'));

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }
    }

    public function install()
    {
      if (!parent::install()
        OR !Configuration::updateValue('CLOUDBANKING_AUTH_KEY', '')
        OR !Configuration::updateValue('CLOUDBANKING_API_VERSION', '')
        OR !Configuration::updateValue('CLOUDBANKING_CUSTOMER_ID', '')
        OR !$this->registerHook('paymentOptions')
        OR !$this->registerHook('paymentReturn') 
        OR !$this->registerHook('backOfficeHeader')
        OR !$this->registerHook('actionOrderStatusUpdate')
        ){
          return false;
      }
      return true;
    }

    public function uninstall()
    {
      if (!Configuration::deleteByName('CLOUDBANKING_AUTH_KEY')
        OR !Configuration::deleteByName('CLOUDBANKING_API_VERSION')
        OR !Configuration::deleteByName('CLOUDBANKING_CUSTOMER_ID')
        // OR !Db::getInstance()->Execute('DROP TABLE `'._DB_PREFIX_.'cloudbanking`')
        OR !$this->unregisterHook('paymentOptions')
        OR !$this->unregisterHook('paymentReturn')
        OR !$this->registerHook('backOfficeHeader')
        OR !parent::uninstall())
        return false;
      return true;
    }
    
    public function installTable()
    {
  
      $sql= "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cloudbanking`(
          `order_id` INT ,
        `cardtoken` VARCHAR(256) NOT NULL
        `banktransaction_id` VARCHAR(256) NOT NULL )";
         
          if(!$result=Db::getInstance()->Execute($sql))
          return false;
    }

    public function getContent()
    {
      $this->_html = '<h2>cloudbanking</h2>';
      if (isset($_POST['submit_cloudbanking']))
      {
        if (empty($_POST['authkey']))
          $this->_postErrors[] = $this->l('AuthKey is required.');
        if (empty($_POST['api_version']))
          $this->_postErrors[] = $this->l('Api Version  is required.');
  
        if (empty($_POST['customer_id']))
          $this->_postErrors[] = $this->l('Customer ID is required.');
        if (!sizeof($this->_postErrors))
        {
          Configuration::updateValue('CLOUDBANKING_AUTH_KEY', strval($_POST['authkey']));
          Configuration::updateValue('CLOUDBANKING_API_VERSION', strval($_POST['api_version']));
          Configuration::updateValue('CLOUDBANKING_CUSTOMER_ID', strval($_POST['customer_id']));
          $this->displayConf();
        }
        else
          $this->displayErrors();
      }
  
      $this->displaybeGateway();
      $this->displayFormSettings();
      return $this->_html;
    }
  
    public function displayConf()
    {
      $this->_html .= '
        <div class="conf confirm">
        <img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
        '.$this->l('Settings updated').'
        </div>';
    }

    public function displayErrors()
    {
      $nbErrors = sizeof($this->_postErrors);
      $this->_html .= '
        <div class="alert error">
        <h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
        <ol>';
      foreach ($this->_postErrors AS $error)
        $this->_html .= '<li>'.$error.'</li>';
      $this->_html .= '
        </ol>
        </div>';
    }
    public function displaybeGateway()
    {
      $this->_html .= '
        <img src="../modules/cloudbanking/cloudbanking_logo_admin.png" style="float:left; margin-right:15px;" />
        <b>'.$this->l('This module allows you to accept credit or debit card payments.').'</b><br /><br />
        '.$this->l('You need to configure your account with your payment processor first before using this module.').'
        <div style="clear:both;">&nbsp;</div>';
    }

    public function displayFormSettings()
    {
      $conf = Configuration::getMultiple(array('CLOUDBANKING_AUTH_KEY', 'CLOUDBANKING_API_VERSION', 'CLOUDBANKING_CUSTOMER_ID'));
      $authkey = array_key_exists('authkey', $_POST) ? $_POST['authkey'] : (array_key_exists('CLOUDBANKING_AUTH_KEY', $conf) ? $conf['CLOUDBANKING_AUTH_KEY'] : '');
      $api_version = array_key_exists('api_version', $_POST) ? $_POST['api_version'] : (array_key_exists('CLOUDBANKING_API_VERSION', $conf) ? $conf['CLOUDBANKING_API_VERSION'] : '');
      $customer_id= array_key_exists('customer_id', $_POST) ? $_POST['customer_id'] : (array_key_exists('CLOUDBANKING_CUSTOMER_ID', $conf) ? $conf['CLOUDBANKING_CUSTOMER_ID'] : '');
      $achk_str = '';
      $pchk_str = '';
  
      $this->_html .= '
        <form action="'.$_SERVER['REQUEST_URI'].'" method="post" style="clear: both;margin-left: 15%;margin-right: 30%;">
          <fieldset>
            
            <label>'.$this->l('Auth Key').'</label>
            <div class="margin-form"><input type="text" size="33" name="authkey" value="'.htmlentities($authkey, ENT_COMPAT, 'UTF-8').'" /></div>
            <label>'.$this->l('Api Version').'</label>
            <div class="margin-form"><input type="text" size="82" name="api_version" value="'.htmlentities($api_version, ENT_COMPAT, 'UTF-8').'" />
            </div>
            <label>'.$this->l('Customer ID').'</label>
            <div class="margin-form"><input type="text" size="82" name="customer_id" value="'.htmlentities($customer_id, ENT_COMPAT, 'UTF-8').'" />
            </div>
  
            <br />
  
            <br /><center><input type="submit" name="submit_cloudbanking" value="'.$this->l('Update settings').'" class="button" /></center>
          </fieldset>
        </form>
        ';
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $payment_options = [
            $this->getEmbeddedPaymentOption(),
        ];

        return $payment_options;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function getEmbeddedPaymentOption()
    {
        $embeddedOption = new PaymentOption();
        $embeddedOption->setCallToActionText($this->l('Cloudbanking'))
                       ->setForm($this->generateForm())
                       ->setAdditionalInformation($this->context->smarty->fetch('module:cloudbanking/views/templates/front/payment_infos.tpl'))
                       ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/payment.jpg'));

        return $embeddedOption;
    }
    
    protected function generateForm()
    {
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $months[] = sprintf("%02d", $i);
        }

        $years = [];
        for ($i = 0; $i <= 10; $i++) {
            $years[] = date('Y', strtotime('+'.$i.' years'));
        }

        $this->context->smarty->assign([
            'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
            'months' => $months,
            'years' => $years,
        ]);

        return $this->context->smarty->fetch('module:cloudbanking/views/templates/front/payment_form.tpl');
    }
    // To Refund from cloudbanking
    public function hookActionOrderStatusUpdate($params)
    {
      if($params['newOrderStatus']->name=='Refunded'){

        $id_cart = Db::getInstance()->getValue('SELECT id_cart FROM '._DB_PREFIX_.'orders WHERE id_order = '.(int)$params['id_order']);
         
        $cloud_data = Db::getInstance()->getRow('SELECT * FROM '._DB_PREFIX_.'cloudbanking WHERE cart_id = '.$id_cart);
      
        $gateway= $this->gateway_instance();

        $refundRequest = $gateway->refund(array(	  
          'cardReference' 		=> $cloud_data['cardtoken'],
          'transactionReference'	=> $cloud_data['banktransaction_id'],
        ));
        
        $refundResponse = $refundRequest->send();
        if ($refundResponse->isSuccessful()) {
          return true;
        }
        else {
          Tools::redirect($_SERVER['HTTP_REFERER'].'&error_refund=1');
        }
    }
}
    public function gateway_instance(){
      $gateway = Omnipay::create('CloudBanking');
      $gateway->setAuthkey(Configuration::get('CLOUDBANKING_AUTH_KEY'));
      $gateway->setApiVersion( Configuration::get('CLOUDBANKING_API_VERSION') );
      $gateway->setCustomerReference( Configuration::get('CLOUDBANKING_CUSTOMER_ID'));
      return $gateway;
    }
}
