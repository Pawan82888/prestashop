<?php
require_once('./'.'/vendor/autoload.php');

use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class CloudbankingValidationModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'cloudbanking') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'validation'));
        }

        $this->context->smarty->assign([
            'params' => $_REQUEST,
        ]);
      
        $customer = new Customer($cart->id_customer);
       
        if (!Validate::isLoadedObject($customer))
            Tools::redirect('index.php?controller=order&step=1');
            

        $currency = $this->context->currency;
        $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $mailVars = array(
            '{bankwire_owner}' => Configuration::get('BANK_WIRE_OWNER'),
            '{bankwire_details}' => nl2br(Configuration::get('BANK_WIRE_DETAILS')),
            '{bankwire_address}' => nl2br(Configuration::get('BANK_WIRE_ADDRESS'))
        );
       
        $data=$_GET;
        $card = $this->createcard($data);
        $gateway = $this->gateway_instance();
        $gateway->setParameter('card', $card);
		$createCardRequest = $gateway->createCard();
		$cardCreateResponse = $createCardRequest->send();
        if ($cardCreateResponse->isSuccessful()) {
			// Process transaction
			$cardToken = $cardCreateResponse->getToken();
            $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			$transaction = $gateway->purchase(array(	  
					'cardReference' 		=> $cardToken,
					'amount'     			=> $total,
					'transactionId'			=> $cart->id,
			));

			$response = $transaction->send();
			if ($response->isSuccessful()) {
				// echo "Purchase transaction was successful!\n";
                $banktransactionid = $response->getTransactionReference();
                $cardtoken=$response->getCardReference();
               
                $sql= "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."cloudbanking`(
                  `cart_id` INT ,
                  `cardtoken` VARCHAR(256) NOT NULL,
                  `banktransaction_id` VARCHAR(256))";

                Db::getInstance()->Execute($sql);
               
                $insertData = array(
                    'cart_id'  => $cart->id, 
                    'cardtoken'  =>  $cardtoken, 
                    'banktransaction_id'   =>  $banktransactionid, 
                    
                 );
                Db::getInstance()->insert("cloudbanking", $insertData);
               
                $this->module->validateOrder($cart->id, Configuration::get('PS_OS_BANKWIRE'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
                Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
         
			}
			else {
			
			}
		}
    }


    public function gateway_instance(){
        $gateway = Omnipay::create('CloudBanking');
        $gateway->setAuthkey(Configuration::get('CLOUDBANKING_AUTH_KEY'));
        $gateway->setApiVersion( Configuration::get('CLOUDBANKING_API_VERSION') );
        $gateway->setCustomerReference( Configuration::get('CLOUDBANKING_CUSTOMER_ID'));
        return $gateway;
    }

    public function createcard($data) {
		
		$card = new CreditCard();

        // Card details
        $card->setName($data['firstname']);
		$card->setNumber($data['card-number']);
		$card->setExpiryYear($data['card-expiry-year']);
		$card->setExpiryMonth($data['card-expiry-month']);
		$card->setCvv($data['card-cvc']);
       
        $cart = $this->context->cart;
        $customer = new Customer((int)($cart->id_customer));
        $address = new Address(intval($cart->id_address_invoice));
        $country = Country::getIsoById((int)$address->id_country);
        $currency = new Currency((int)($cart->id_currency));
        $currency_code=trim($currency->iso_code);
        $amount =(float)$cart->getOrderTotal(true, Cart::BOTH);
      
        // Billing details
		$card->setBillingFirstName($address->firstname);
		$card->setBillingLastName($address->lastname);
		$card->setBillingAddress1($address->address1);
		$card->setBillingAddress2($address->address2);
		$card->setBillingCity($address->city);
		$card->setBillingCountry($address->country);
		$card->setBillingPhone($address->phone_mobile);
		$card->setBillingCompany($address->company);
		$card->setBillingPostcode($address->postcode);
		return $card;
    }
}
